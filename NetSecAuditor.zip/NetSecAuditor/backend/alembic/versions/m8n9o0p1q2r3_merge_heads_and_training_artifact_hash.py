"""Merge divergent heads; add TrainingJob.artifact_hash

`alembic upgrade head` on a clean database was actually broken before this
migration: L1m2n3o4p5q6 (training/HITL tables) branched off
h2i3j4k5l6m7, while k5l6m7n8o9p0 (device inventory fields) continued the
other branch through i3j4k5l6m7n8 -> j4k5l6m7n8o9. That left two
unmerged heads, which alembic refuses to resolve automatically -- this is
the Phase 42 "no migration requires manual intervention" gate failing in
practice, not just in theory.

Also adds `artifact_hash` to `training_jobs`, which the acceptance spec
requires be recorded per training job (dataset_version, base_model,
started_at/completed_at, artifact_path, artifact_hash, metrics, error,
created_by) but which the original table only partially had.

Revision ID: m8n9o0p1q2r3
Revises: L1m2n3o4p5q6, k5l6m7n8o9p0
Create Date: 2026-09-07 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = 'm8n9o0p1q2r3'
down_revision = ('L1m2n3o4p5q6', 'k5l6m7n8o9p0')
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("training_jobs", sa.Column("artifact_hash", sa.String(), nullable=True))


def downgrade():
    op.drop_column("training_jobs", "artifact_hash")
