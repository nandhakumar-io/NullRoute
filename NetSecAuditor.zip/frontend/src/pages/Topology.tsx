import { useEffect, useState, useRef } from "react";
import { endpoints, Topology as TopologyData } from "../api";
import { PageHeader, Loading, EmptyState } from "../components/ui";
import ForceGraph2D from "react-force-graph-2d";

export default function Topology() {
  const [topology, setTopology] = useState<TopologyData | null>(null);

  useEffect(() => {
    endpoints.topology().then((r) => setTopology(r.data));
  }, []);

  if (!topology) return <Loading />;

  const { nodes, links } = topology;

  const graphData = {
    nodes: nodes.map(n => ({ ...n, val: 5 })),
    links: links.map(l => ({ ...l, source: l.source_device_id, target: l.target_device_id })),
  };

  return (
    <div className="h-full flex flex-col min-h-screen">
      <PageHeader
        title="Topology"
        subtitle="Devices and inferred adjacencies, derived from collected interface data (Phase 9)"
      />
      <div className="flex-1 px-8 pb-8 relative">
        {nodes.length === 0 ? (
          <EmptyState message="No devices yet. Upload or collect a configuration first." />
        ) : (
          <div className="h-[75vh] card p-0 border border-soc-border overflow-hidden rounded-xl bg-slate-900/50">
            <ForceGraph2D
              graphData={graphData}
              nodeLabel="hostname"
              nodeAutoColorBy="vendor"
              linkDirectionalArrowLength={3.5}
              linkDirectionalArrowRelPos={1}
              linkColor={() => "#475569"}
              backgroundColor="#0f172a"
            />
          </div>
        )}
      </div>
    </div>
  );
}
