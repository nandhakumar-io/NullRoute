import { useEffect, useState } from "react";
import { api, endpoints, AIHealth, ComplianceSummary, ServiceHealthEntry, SystemHealth as SystemHealthData } from "../api";
import { PageHeader, Loading, StatCard } from "../components/ui";

// Grafana is an optional, separately self-hosted piece of this stack (see
// docker-compose.infra.yml). Embedding it in an <iframe> unconditionally
// meant this page rendered a permanently blank box for every install that
// hasn't stood Grafana up -- the iframe's onError never fires for a
// same-origin-policy / X-Frame-Options / connection-refused failure, only
// for a handful of resource-load errors browsers rarely emit for iframes.
// This page now renders real data straight from the API (the same sources
// System Health and the Dashboard already use) so it works with zero extra
// infrastructure, and only *offers* the Grafana embed as an optional deep
// dive once we've actually confirmed Grafana is reachable.
const GRAFANA_URL = (import.meta as any).env?.VITE_GRAFANA_URL || "http://localhost:3001/d/compliance-overview?orgId=1&kiosk";

const STATUS_BADGE_CLASS: Record<string, string> = {
  HEALTHY: "badge-pass",
  DEGRADED: "badge-medium",
  UNAVAILABLE: "badge-fail",
  ERROR: "badge-critical",
  DISABLED: "badge-na",
};

function StatusPill({ status }: { status: string }) {
  return <span className={`badge ${STATUS_BADGE_CLASS[status] || "badge-na"}`}>{status}</span>;
}

function ServiceRow({ svc }: { svc: ServiceHealthEntry }) {
  return (
    <div className="flex items-start justify-between py-3 border-b border-soc-border last:border-b-0">
      <div className="min-w-0 pr-4">
        <div className="text-sm font-medium text-slate-200">{svc.name}</div>
        {svc.detail && <div className="text-xs text-slate-500 mt-0.5">{svc.detail}</div>}
        {svc.error && <div className="text-xs text-red-400 mt-0.5 break-words">{svc.error}</div>}
      </div>
      <div className="flex items-center gap-2 shrink-0">
        {typeof svc.latency_ms === "number" && (
          <span className="text-xs text-slate-600">{svc.latency_ms} ms</span>
        )}
        <StatusPill status={svc.status} />
      </div>
    </div>
  );
}

export default function Observability() {
  const [systemHealth, setSystemHealth] = useState<SystemHealthData | null>(null);
  const [aiHealth, setAiHealth] = useState<AIHealth | null>(null);
  const [summary, setSummary] = useState<ComplianceSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [grafanaReachable, setGrafanaReachable] = useState(false);
  const [showGrafana, setShowGrafana] = useState(false);

  async function load() {
    setError(null);
    try {
      const [healthRes, aiRes, summaryRes] = await Promise.all([
        endpoints.systemHealth(),
        endpoints.aiHealth().catch(() => ({ data: null })),
        endpoints.complianceSummary().catch(() => ({ data: null })),
      ]);
      setSystemHealth(healthRes.data);
      setAiHealth(aiRes.data);
      setSummary(summaryRes.data);
    } catch (e: any) {
      setError(e?.response?.data?.detail || "Could not reach the API to load observability data.");
    } finally {
      setLoading(false);
    }

    // Grafana is genuinely optional -- probe it separately so a missing
    // Grafana never blocks the rest of this page from rendering.
    fetch(GRAFANA_URL, { mode: "no-cors" })
      .then(() => setGrafanaReachable(true))
      .catch(() => setGrafanaReachable(false));
  }

  useEffect(() => {
    load();
    const t = setInterval(load, 15000);
    return () => clearInterval(t);
  }, []);

  if (loading && !systemHealth) return <Loading />;

  const allServices = [...(systemHealth?.core_services || []), ...(systemHealth?.optional_integrations || [])];
  const degradedOrDown = allServices.filter((s) => s.status !== "HEALTHY" && s.status !== "DISABLED");

  return (
    <div>
      <PageHeader
        title="System Observability"
        subtitle="Service health, AI pipeline status, and queue/worker activity across the platform"
        action={
          <div className="flex items-center gap-3">
            {systemHealth && <StatusPill status={systemHealth.overall_status} />}
            <button onClick={load} className="btn-secondary">Refresh</button>
          </div>
        }
      />

      <div className="px-8 pb-8 space-y-6">
        {error && (
          <div className="card border border-red-500/30 text-sm text-red-400">{error}</div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            label="Services Reporting Issues"
            value={degradedOrDown.length}
            tone={degradedOrDown.length === 0 ? "good" : "critical"}
          />
          <StatCard
            label="AI Pipeline"
            value={aiHealth?.classifier_loaded && aiHealth?.embedder_loaded ? "Ready" : "Degraded"}
            tone={aiHealth?.classifier_loaded && aiHealth?.embedder_loaded ? "good" : "medium"}
          />
          <StatCard
            label="Pending HITL Reviews"
            value={summary?.ai_health.pending_hitl_reviews ?? "—"}
            tone={summary && summary.ai_health.pending_hitl_reviews > 0 ? "medium" : "good"}
          />
          <StatCard
            label="Ollama Reachable"
            value={summary ? (summary.ai_health.ollama_reachable ? "Yes" : "No") : "—"}
            tone={summary?.ai_health.ollama_reachable ? "good" : "critical"}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="card">
            <h3 className="text-sm font-semibold text-slate-100 mb-4 border-b border-soc-border pb-2">Core Services</h3>
            <div className="space-y-0">
              {systemHealth ? (
                systemHealth.core_services.map((svc) => <ServiceRow key={svc.name} svc={svc} />)
              ) : (
                <div className="text-sm text-slate-500 py-3">Unavailable — could not reach the API.</div>
              )}
            </div>
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold text-slate-100 mb-4 border-b border-soc-border pb-2">Optional Integrations</h3>
            <div className="space-y-0">
              {systemHealth ? (
                systemHealth.optional_integrations.map((svc) => <ServiceRow key={svc.name} svc={svc} />)
              ) : (
                <div className="text-sm text-slate-500 py-3">Unavailable — could not reach the API.</div>
              )}
            </div>
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold text-slate-100 mb-4 border-b border-soc-border pb-2">AI / ML Pipelines</h3>
            {aiHealth ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-slate-200">Zero-Shot Classifier</div>
                    <div className="text-xs text-slate-500">{aiHealth.classifier_backend} ({aiHealth.model_version})</div>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${aiHealth.classifier_loaded ? "bg-emerald-950/50 text-emerald-400" : "bg-amber-950/50 text-amber-500"}`}>
                    {aiHealth.classifier_loaded ? "Ready" : "Not Loaded"}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-slate-200">Semantic Embedder</div>
                    <div className="text-xs text-slate-500">{aiHealth.embedder_backend} (Dataset: {aiHealth.reference_examples} examples)</div>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${aiHealth.embedder_loaded ? "bg-emerald-950/50 text-emerald-400" : "bg-amber-950/50 text-amber-500"}`}>
                    {aiHealth.embedder_loaded ? "Ready" : "Not Loaded"}
                  </span>
                </div>
                {summary && (
                  <div className="flex items-center justify-between pt-2 border-t border-soc-border">
                    <div className="text-sm font-medium text-slate-200">Production Model</div>
                    <div className="text-xs text-slate-400 font-mono">
                      {summary.ai_health.production_model || "none promoted"}
                      {summary.ai_health.production_model_macro_f1 != null &&
                        ` (F1 ${summary.ai_health.production_model_macro_f1.toFixed(2)})`}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-sm text-slate-500">AI service unreachable.</div>
            )}
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold text-slate-100 mb-4 border-b border-soc-border pb-2">Severity Heatmap (Open Findings)</h3>
            {summary ? (
              <div className="grid grid-cols-2 gap-3">
                <StatCard label="Critical" value={summary.severity_heatmap.CRITICAL} tone="critical" />
                <StatCard label="High" value={summary.severity_heatmap.HIGH} tone="high" />
                <StatCard label="Medium" value={summary.severity_heatmap.MEDIUM} tone="medium" />
                <StatCard label="Low" value={summary.severity_heatmap.LOW} tone="low" />
              </div>
            ) : (
              <div className="text-sm text-slate-500">No compliance data yet.</div>
            )}
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-100">Grafana Dashboard (optional)</h3>
              <div className="text-xs text-slate-500 mt-1">
                Detailed scan-duration, AI-inference-latency and queue-depth time series, collected via
                OpenTelemetry → VictoriaMetrics → Grafana (self-hosted, see{" "}
                <code className="text-cyan-400">docker-compose.infra.yml</code>). Import{" "}
                <code className="text-cyan-400">docs/grafana-dashboard.json</code> on first run.
              </div>
            </div>
            <span className={`badge ${grafanaReachable ? "badge-pass" : "badge-na"}`}>
              {grafanaReachable ? "Reachable" : "Not detected"}
            </span>
          </div>
          {grafanaReachable ? (
            showGrafana ? (
              <div className="aspect-video bg-black/40 rounded-lg border border-soc-border overflow-hidden">
                <iframe src={GRAFANA_URL} title="Grafana dashboard" className="w-full h-full" />
              </div>
            ) : (
              <button onClick={() => setShowGrafana(true)} className="btn-secondary text-sm">
                Load Grafana dashboard
              </button>
            )
          ) : (
            <div className="text-sm text-slate-500">
              Grafana isn't reachable at <code className="text-cyan-400">{GRAFANA_URL}</code>. Start the optional
              observability stack (<code className="text-cyan-400">docker compose -f docker-compose.infra.yml up -d</code>) to enable it.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}