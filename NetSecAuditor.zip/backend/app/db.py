import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.db import Base

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg2://compliance:compliance@postgres:5432/compliance",
)

FALLBACK_SQLITE = "sqlite:///./compliance_local.db"


def _build_engine():
    try:
        engine = create_engine(DATABASE_URL, pool_pre_ping=True)
        with engine.connect():
            pass
        return engine
    except Exception:
        # Local/offline dev fallback so the API is usable without the full
        # docker-compose stack running.
        return create_engine(FALLBACK_SQLITE, connect_args={"check_same_thread": False})


engine = _build_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """Bring the schema up to date.

    Once Alembic migrations exist they are the source of truth (RULE in
    section 21: "do not rely solely on create_all once migrations exist").
    We only fall back to `create_all` for the local/offline SQLite dev
    fallback (see `_build_engine` above), where running the full Alembic
    stack isn't worth the friction for a throwaway file.
    """
    if engine.url.get_backend_name() == "sqlite":
        Base.metadata.create_all(bind=engine)
        return

    import os as _os

    from alembic import command
    from alembic.config import Config

    alembic_ini = _os.path.join(_os.path.dirname(__file__), "..", "alembic.ini")
    cfg = Config(alembic_ini)
    cfg.set_main_option("sqlalchemy.url", str(engine.url))
    try:
        command.upgrade(cfg, "head")
    except Exception:
        # Alembic couldn't run (e.g. versions table locked mid-deploy on
        # another replica, or migrations not shipped in this build) -
        # fall back to create_all so the API doesn't hard-fail on boot.
        # This never *reverts* a migration; it only fills in missing
        # tables, so it's safe alongside a partially-migrated schema.
        Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
