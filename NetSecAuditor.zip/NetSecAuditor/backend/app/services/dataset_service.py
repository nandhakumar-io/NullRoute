"""
Dataset Service - Loop 2 (Offline Training Orchestration)
"""
import json
import hashlib
from typing import Any, Dict, List, Optional
from datetime import datetime
from sqlalchemy.orm import Session

from app.models.db import TrainingExample, DatasetVersion
from app.ai.frozen_test_set import frozen_test_hashes


def _canonical_example_payload(ex: TrainingExample) -> Dict[str, Any]:
    """Everything that actually affects what a model trained on this
    example would learn. Deliberately excludes DB-internal bookkeeping
    (row id, timestamps, FK ids to scan/device/mapping) so that two
    examples with identical training-relevant content hash identically,
    and so the dataset hash is reproducible from the *content*, not from
    row insertion order or surrogate keys."""
    facts = ex.normalized_facts or {}
    return {
        "raw_config_hash": ex.raw_config_hash,
        "raw_config_redacted": ex.raw_config_redacted,
        "vendor": ex.vendor,
        "intent": ex.intent,
        "normalized_facts": json.loads(json.dumps(facts, sort_keys=True, default=str)),
        "human_action": ex.human_action,
        "source": ex.source_mapping_id,
    }


def _canonical_example_hash(ex: TrainingExample) -> str:
    payload = _canonical_example_payload(ex)
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _compute_hash(examples: List[TrainingExample]) -> str:
    """Canonical, order-independent hash of the full dataset content.

    Order-independent (sorted by per-example hash before hashing the
    joined digest) so that two dataset builds containing the same set of
    examples always produce the same dataset_hash regardless of DB
    iteration order -- required for the "each version must be
    reproducible" acceptance gate.
    """
    per_example_hashes = sorted(_canonical_example_hash(ex) for ex in examples)
    hasher = hashlib.sha256()
    for h in per_example_hashes:
        hasher.update(h.encode("utf-8"))
    return hasher.hexdigest()


def prevent_frozen_test_leakage(example: TrainingExample, frozen_test_hashes_set: set) -> bool:
    """Returns True if the example was excluded for frozen-set leakage."""
    if example.raw_config_hash in frozen_test_hashes_set:
        example.validation_status = "EXCLUDED"
        example.correction_reason = (
            (example.correction_reason + " | " if example.correction_reason else "")
            + "EXCLUDED: raw_config_hash matches an entry in the frozen evaluation set"
        )
        return True
    return False


def create_dataset_version(db: Session, tenant_id: Optional[str], user: Any, version_label: str) -> DatasetVersion:
    # Immutability: a dataset version, once created, can never be silently
    # re-populated or extended. Creating with a label that already exists
    # is a hard error, not a merge.
    existing = db.query(DatasetVersion).filter(DatasetVersion.version == version_label).first()
    if existing:
        raise ValueError(
            f"DatasetVersion '{version_label}' already exists and is immutable. "
            f"Create a new version label instead of reusing an existing one."
        )

    # 1. Load the authoritative frozen-test hashes from the versioned
    # evaluation artifact (NOT derived from HITL examples -- see
    # app/ai/frozen_test_set.py).
    frozen_hashes = frozen_test_hashes()

    q = db.query(TrainingExample).filter(TrainingExample.validation_status == "VALIDATED")
    if tenant_id:
        q = q.filter((TrainingExample.tenant_id == tenant_id) | (TrainingExample.tenant_id.is_(None)))
    examples = q.order_by(TrainingExample.created_at).all()

    # Exclude frozen-set leakage and de-duplicate on raw_config_hash (a
    # dupe is also excluded, since fine-tuning on the exact same raw
    # config twice from two separate corrections adds noise, not signal).
    seen_raw_hashes = set()
    clean_examples = []

    for ex in examples:
        if prevent_frozen_test_leakage(ex, frozen_hashes):
            continue
        if ex.raw_config_hash in seen_raw_hashes:
            ex.validation_status = "EXCLUDED"
            ex.correction_reason = (
                (ex.correction_reason + " | " if ex.correction_reason else "")
                + "EXCLUDED: duplicate raw_config_hash within this dataset build"
            )
            continue
        seen_raw_hashes.add(ex.raw_config_hash)
        clean_examples.append(ex)

    # 2. Build distributions
    vendor_dist: Dict[str, int] = {}
    label_dist: Dict[str, int] = {}
    source_dist: Dict[str, int] = {}
    for ex in clean_examples:
        vendor = ex.vendor or "unknown"
        vendor_dist[vendor] = vendor_dist.get(vendor, 0) + 1

        intent = ex.intent or "unknown"
        label_dist[intent] = label_dist.get(intent, 0) + 1

        src = ex.source_mapping_id or "unknown"
        source_dist[src] = source_dist.get(src, 0) + 1

        # update ex.dataset_version assignment
        ex.dataset_version = version_label

    dataset_hash = _compute_hash(clean_examples)

    dv = DatasetVersion(
        version=version_label,
        tenant_id=tenant_id,
        created_by=user.username if hasattr(user, "username") and user.username else "admin",
        created_at=datetime.utcnow(),
        example_count=len(clean_examples),
        label_distribution=label_dist,
        vendor_distribution=vendor_dist,
        source_distribution=source_dist,
        validation_status="VALIDATED",
        training_status="PENDING",
        dataset_hash=dataset_hash,
        is_immutable=True
    )

    db.add(dv)
    db.commit()
    db.refresh(dv)
    return dv


def get_dataset(db: Session, tenant_id: Optional[str], version_id: str) -> Optional[DatasetVersion]:
    q = db.query(DatasetVersion).filter(DatasetVersion.version == version_id)
    if tenant_id:
        q = q.filter((DatasetVersion.tenant_id == tenant_id) | (DatasetVersion.tenant_id.is_(None)))
    return q.first()


def get_training_examples_for_version(db: Session, dataset_version_label: str) -> List[TrainingExample]:
    """The actual (text, intent) pairs a training job trains on -- only
    examples that survived leakage/dedup filtering and are still tagged
    with this immutable version."""
    return (
        db.query(TrainingExample)
        .filter(
            TrainingExample.dataset_version == dataset_version_label,
            TrainingExample.validation_status == "VALIDATED",
        )
        .order_by(TrainingExample.created_at)
        .all()
    )
