import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { endpoints, Scan, Device } from "../api";
import {
  PageHeader, Loading, EmptyState, StatCard, DecisionPipeline,
  opaTone, batfishTone, riskTone, decisionTone, PipelineStepData,
} from "../components/ui";

const DECISION_OPTIONS = ["ALL", "PASS", "REVIEW", "BLOCK"];

function DecisionPill({ decision }: { decision: string | null | undefined }) {
  const cls =
    decision === "PASS" ? "badge-pass" : decision === "BLOCK" ? "badge-fail" : "badge-medium";
  return <span className={`badge ${cls}`}>{decision || "PENDING"}</span>;
}

function buildSteps(s: Scan): PipelineStepData[] {
  return [
    {
      label: "Normalized",
      value: s.status === "failed" ? "FAILED" : "MODELED",
      tone: s.status === "failed" ? "fail" : "pass",
      sublabel: "Vendor config -> common security model",
    },
    { label: "OPA", value: (s.opa_decision || "PENDING").replace(/_/g, " "), tone: opaTone(s.opa_decision), sublabel: "Deterministic policy engine" },
    { label: "Batfish", value: (s.batfish_status || "N/A").replace(/_/g, " "), tone: batfishTone(s.batfish_status), sublabel: "Network behavior verification" },
    { label: "Risk", value: s.risk_level || "N/A", tone: riskTone(s.risk_level), sublabel: s.risk_score != null ? `score ${s.risk_score}` : undefined },
    { label: "Decision", value: s.final_decision || "PENDING", tone: decisionTone(s.final_decision), sublabel: s.final_reason || undefined },
  ];
}

export default function Validation() {
  const [scans, setScans] = useState<Scan[]>([]);
  const [devices, setDevices] = useState<Record<string, Device>>({});
  const [loading, setLoading] = useState(true);
  const [decisionFilter, setDecisionFilter] = useState("ALL");
  const [search, setSearch] = useState("");

  useEffect(() => {
    Promise.all([
      endpoints.scans(),
      endpoints.devices({ limit: 500 }).catch(() => null),
    ]).then(([scanRes, deviceRes]) => {
      setScans(scanRes.data);
      if (deviceRes) {
        const items = ((deviceRes.data as any).items ?? deviceRes.data) as Device[];
        const map: Record<string, Device> = {};
        (Array.isArray(items) ? items : []).forEach((d) => { map[d.id] = d; });
        setDevices(map);
      }
    }).finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return scans
      .filter((s) => decisionFilter === "ALL" || s.final_decision === decisionFilter)
      .filter((s) => {
        if (!q) return true;
        const device = devices[s.device_id];
        return (
          s.id.toLowerCase().includes(q) ||
          s.framework?.toLowerCase().includes(q) ||
          device?.hostname?.toLowerCase().includes(q) ||
          device?.management_address?.toLowerCase().includes(q)
        );
      });
  }, [scans, decisionFilter, search, devices]);

  if (loading) return <Loading />;

  const counts = {
    PASS: scans.filter((s) => s.final_decision === "PASS").length,
    REVIEW: scans.filter((s) => s.final_decision === "REVIEW").length,
    BLOCK: scans.filter((s) => s.final_decision === "BLOCK").length,
    PENDING: scans.filter((s) => !s.final_decision).length,
  };

  return (
    <div className="pb-10">
      <PageHeader
        title="Validation"
        subtitle="Correlated decision per scan — OPA (deterministic policy) × Batfish (network behavior) × Risk, per the correlation precedence rules. The LLM never determines this outcome."
      />

      <div className="px-8 grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard label="Passed" value={counts.PASS} tone="good" />
        <StatCard label="Needs Review" value={counts.REVIEW} tone="medium" />
        <StatCard label="Blocked" value={counts.BLOCK} tone="critical" />
        <StatCard label="Pending" value={counts.PENDING} tone="default" />
      </div>

      <div className="px-8 pb-8 space-y-4">
        <div className="flex gap-3 items-center flex-wrap justify-between">
          <div className="flex gap-3 items-center flex-wrap">
            <select className="select" value={decisionFilter} onChange={(e) => setDecisionFilter(e.target.value)}>
              {DECISION_OPTIONS.map((d) => (
                <option key={d} value={d}>{d === "ALL" ? "All decisions" : d}</option>
              ))}
            </select>
            <input
              className="input w-64"
              placeholder="Search by device, scan ID, or framework…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <span className="text-xs text-slate-500">{filtered.length} of {scans.length} scans</span>
        </div>

        {filtered.length === 0 && <EmptyState message="No scans match this filter." />}

        {filtered.map((s) => {
          const device = devices[s.device_id];
          return (
            <Link key={s.id} to={`/scans/${s.id}`} className="card block hover:border-cyan-700/60 hover:shadow-cyan-900/10 transition-all">
              <div className="flex items-start justify-between gap-6 flex-wrap mb-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-slate-200">
                      {device?.hostname || device?.management_address || `Device ${s.device_id.slice(0, 8)}`}
                    </span>
                    <DecisionPill decision={s.final_decision} />
                    {device?.vendor && <span className="badge bg-slate-800 text-slate-400 border border-slate-700 text-[10px]">{device.vendor}</span>}
                  </div>
                  <div className="text-xs text-slate-500 mt-1 flex items-center gap-2 flex-wrap">
                    <span className="font-mono">{s.id.slice(0, 8)}</span>
                    <span>·</span>
                    <span>{s.framework}</span>
                    <span>·</span>
                    <span>{new Date(s.created_at).toLocaleString()}</span>
                    <span>·</span>
                    <span className={s.evidence_id ? "text-emerald-600" : "text-slate-500"}>
                      {s.evidence_id ? "Evidence anchored" : "No evidence yet"}
                    </span>
                  </div>
                </div>
                <div className="shrink-0 text-right">
                  <div className="text-2xl font-bold text-slate-100">
                    {s.compliance_score != null ? `${s.compliance_score}%` : "—"}
                  </div>
                  <div className="text-[10px] uppercase tracking-wide text-slate-500">compliance</div>
                </div>
              </div>

              <DecisionPipeline steps={buildSteps(s)} />

              {s.final_reason && (
                <div className="text-xs text-slate-500 mt-4 pt-3 border-t border-soc-border">{s.final_reason}</div>
              )}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
