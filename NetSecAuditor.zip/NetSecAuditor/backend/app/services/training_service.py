"""
Training Service - Loop 2 (Offline Model Training Job Orchestration)

Real DistilBERT fine-tuning, runnable on CPU (GPU is used automatically
if `torch.cuda.is_available()`). This module never fabricates metrics: if
training dependencies are missing, the dataset doesn't have enough
labeled data, or fine-tuning itself throws, the job is marked FAILED with
the real exception message -- never silently downgraded to placeholder
metrics.

Every successful run produces a real model artifact on disk, a real
SHA-256 hash of that artifact, and metrics computed by actually running
the fine-tuned model against a held-out validation split AND the
authoritative frozen test set (see app/ai/frozen_test_set.py). It then
registers the result as a CANDIDATE via model_registry_service -- never
auto-promoted; human approval + explicit admin promotion are still
required (see model_registry_service.approve_candidate /
promote_to_production).
"""
from __future__ import annotations

import hashlib
import os
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy.orm import Session

from app.models.db import TrainingJob, DatasetVersion, TrainingExample
from app.ai.classifier import KNOWN_INTENTS
from app.ai.schemas import UNKNOWN_INTENT
from app.ai.frozen_test_set import load_frozen_test_set

# A candidate trained on too little data isn't a real candidate -- it's
# noise wearing a metrics dashboard. Fail loudly instead.
MIN_EXAMPLES_PER_CLASS = 2
MIN_TOTAL_EXAMPLES = 6


def create_training_job(
    db: Session,
    tenant_id: Optional[str],
    dataset_version_id: str,
    base_model_version: Optional[str],
    user: Any
) -> TrainingJob:

    dv = db.query(DatasetVersion).filter(DatasetVersion.id == dataset_version_id).first()
    if not dv:
        raise ValueError(f"DatasetVersion {dataset_version_id} not found")

    job = TrainingJob(
        tenant_id=tenant_id,
        dataset_version_id=dataset_version_id,
        base_model_version=base_model_version,
        status="QUEUED",
        created_by=user.username if hasattr(user, "username") and user.username else "admin",
    )

    db.add(job)
    db.commit()
    db.refresh(job)

    # Orchestration note: this only enqueues the row. Actual execution is
    # triggered separately via run_training_job -- callers running in
    # production should invoke that from a background worker / NATS
    # consumer (matching the pattern in app/workers/*), not inline in the
    # request that creates the job, since a real fine-tuning run can take
    # minutes even on a small dataset. The /run endpoint in
    # routers/training_jobs.py currently invokes it synchronously, which
    # is intentional for tests/demo use but should be backed by a worker
    # for a real multi-user deployment.

    return job


def _training_text(ex: TrainingExample) -> str:
    return ex.raw_config_redacted


def _label_for(intent: Optional[str]) -> str:
    return intent if intent else UNKNOWN_INTENT


def _split_train_val(paired: List[Tuple[str, str]], val_fraction: float = 0.2):
    """Per-class split so every class with >=2 examples contributes at
    least one to validation, without starving training on rare classes."""
    by_label: Dict[str, List[Tuple[str, str]]] = defaultdict(list)
    for item in paired:
        by_label[item[1]].append(item)

    train: List[Tuple[str, str]] = []
    val: List[Tuple[str, str]] = []
    for _label, items in by_label.items():
        if len(items) < 2:
            train.extend(items)
            continue
        n_val = max(1, int(len(items) * val_fraction))
        val.extend(items[:n_val])
        train.extend(items[n_val:])
    return train, val


def _artifact_dir(job_id: str) -> Path:
    base = os.getenv("AI_TRAINING_ARTIFACT_DIR", "/tmp/netsecauditor_model_artifacts")
    d = Path(base) / job_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def _hash_dir(path: Path) -> str:
    """Real SHA-256 over every artifact file's relative path + bytes, so
    the hash actually represents what's on disk (not just a filename or
    a metrics dict) and changes if any weight file changes."""
    hasher = hashlib.sha256()
    for f in sorted(path.rglob("*")):
        if f.is_file():
            hasher.update(f.relative_to(path).as_posix().encode("utf-8"))
            hasher.update(f.read_bytes())
    return hasher.hexdigest()


def _compute_metrics(y_true: List[str], y_pred: List[str], avg_latency_ms: float) -> Dict[str, Any]:
    """Precision/recall/F1 computed directly (no sklearn dependency) so
    this module has no additional runtime dependency beyond torch/
    transformers, which the classifier already requires."""
    labels = sorted(set(y_true) | set(y_pred))
    n = len(y_true)
    correct = sum(1 for t, p in zip(y_true, y_pred) if t == p)
    accuracy = (correct / n) if n else 0.0

    precisions, recalls, f1s, supports = {}, {}, {}, {}
    for label in labels:
        tp = sum(1 for t, p in zip(y_true, y_pred) if t == label and p == label)
        fp = sum(1 for t, p in zip(y_true, y_pred) if t != label and p == label)
        fn = sum(1 for t, p in zip(y_true, y_pred) if t == label and p != label)
        support = sum(1 for t in y_true if t == label)
        precision = tp / (tp + fp) if (tp + fp) else 0.0
        recall = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
        precisions[label], recalls[label], f1s[label], supports[label] = precision, recall, f1, support

    macro_precision = sum(precisions.values()) / len(labels) if labels else 0.0
    macro_recall = sum(recalls.values()) / len(labels) if labels else 0.0
    macro_f1 = sum(f1s.values()) / len(labels) if labels else 0.0
    total_support = sum(supports.values()) or 1
    weighted_f1 = sum(f1s[l] * supports[l] for l in labels) / total_support

    if UNKNOWN_INTENT in labels and supports[UNKNOWN_INTENT] > 0:
        unknown_precision = precisions[UNKNOWN_INTENT]
        unknown_recall = recalls[UNKNOWN_INTENT]
        unknown_f1 = f1s[UNKNOWN_INTENT]
    else:
        # No UNKNOWN examples in this eval slice -- report None rather
        # than fabricating a value that implies UNKNOWN was measured.
        unknown_precision = unknown_recall = unknown_f1 = None

    return {
        "accuracy": round(accuracy, 4),
        "macro_precision": round(macro_precision, 4),
        "macro_recall": round(macro_recall, 4),
        "macro_f1": round(macro_f1, 4),
        "weighted_f1": round(weighted_f1, 4),
        "unknown_precision": round(unknown_precision, 4) if unknown_precision is not None else None,
        "unknown_recall": round(unknown_recall, 4) if unknown_recall is not None else None,
        "unknown_f1": round(unknown_f1, 4) if unknown_f1 is not None else None,
        "latency_ms": round(avg_latency_ms, 3),
        "eval_set_size": n,
        "label_support": supports,
    }


def run_training_job(db: Session, job_id: str) -> None:
    job = db.query(TrainingJob).filter(TrainingJob.id == job_id).first()
    if not job:
        return

    job.status = "RUNNING"
    job.started_at = datetime.utcnow()
    db.commit()

    try:
        dv = db.query(DatasetVersion).filter(DatasetVersion.id == job.dataset_version_id).first()
        if not dv:
            raise ValueError(f"DatasetVersion {job.dataset_version_id} not found")

        from app.services.dataset_service import get_training_examples_for_version
        examples = get_training_examples_for_version(db, dv.version)

        # Only APPROVED/CORRECTED examples carry a human-validated label.
        # REJECTED examples must never contribute positive training
        # signal -- they exist to *record* a rejected AI suggestion, not
        # to teach the model anything.
        examples = [ex for ex in examples if ex.human_action in ("APPROVED", "CORRECTED") and ex.intent]

        texts = [_training_text(ex) for ex in examples]
        labels = [_label_for(ex.intent) for ex in examples]

        label_counts: Dict[str, int] = {}
        for l in labels:
            label_counts[l] = label_counts.get(l, 0) + 1

        under_represented = sorted(l for l, c in label_counts.items() if c < MIN_EXAMPLES_PER_CLASS)
        if len(texts) < MIN_TOTAL_EXAMPLES or len(label_counts) < 2 or under_represented:
            raise RuntimeError(
                f"Insufficient training data in dataset version '{dv.version}': "
                f"{len(texts)} usable examples across {len(label_counts)} classes "
                f"(need >= {MIN_TOTAL_EXAMPLES} examples, >= 2 classes, "
                f">= {MIN_EXAMPLES_PER_CLASS} examples/class). "
                f"Under-represented classes: {under_represented or '[]'}."
            )

        try:
            import torch
            from torch.utils.data import Dataset as TorchDataset
            from transformers import (
                AutoTokenizer,
                AutoModelForSequenceClassification,
                Trainer,
                TrainingArguments,
            )
        except ImportError as e:
            raise RuntimeError(f"Training dependencies not installed (torch/transformers): {e}")

        # Resolution order matches classifier.py's own conventions: an
        # explicit per-job base model, then a local offline checkpoint
        # path (for air-gapped deployments), then the public HF repo id.
        base_model = (
            job.base_model_version
            or os.getenv("AI_TRAINING_BASE_MODEL_PATH")
            or os.getenv("AI_TRAINING_BASE_MODEL", "distilbert-base-uncased")
        )
        hf_token = os.getenv("HF_TOKEN") or None

        # Deterministic label set: union of what's actually in this
        # dataset, the full known-intent vocabulary, and UNKNOWN -- so the
        # resulting checkpoint's id2label always matches classifier.py's
        # KNOWN_INTENTS. Production inference resolves predictions by
        # label name, never by raw index, so this only needs to be a
        # superset, not an exact match run-to-run.
        all_labels = sorted(set(KNOWN_INTENTS) | set(label_counts.keys()) | {UNKNOWN_INTENT})
        label2id = {l: i for i, l in enumerate(all_labels)}
        id2label = {i: l for l, i in label2id.items()}

        paired = list(zip(texts, labels))
        train_pairs, val_pairs = _split_train_val(paired)
        if not train_pairs:
            raise RuntimeError("Train/validation split left zero training examples.")

        tokenizer = AutoTokenizer.from_pretrained(base_model, token=hf_token)
        model = AutoModelForSequenceClassification.from_pretrained(
            base_model,
            token=hf_token,
            num_labels=len(all_labels),
            id2label=id2label,
            label2id=label2id,
            ignore_mismatched_sizes=True,
        )

        class _IntentDataset(TorchDataset):
            def __init__(self, pairs):
                self.pairs = pairs

            def __len__(self):
                return len(self.pairs)

            def __getitem__(self, idx):
                text, label = self.pairs[idx]
                enc = tokenizer(text, truncation=True, max_length=64, padding="max_length")
                enc.pop("token_type_ids", None)
                item = {k: torch.tensor(v) for k, v in enc.items()}
                item["labels"] = torch.tensor(label2id[label])
                return item

        train_ds = _IntentDataset(train_pairs)

        artifact_dir = _artifact_dir(job.id)
        epochs = int(os.getenv("AI_TRAINING_EPOCHS", "3"))
        batch_size = int(os.getenv("AI_TRAINING_BATCH_SIZE", "8"))

        training_args = TrainingArguments(
            output_dir=str(artifact_dir / "checkpoints"),
            num_train_epochs=epochs,
            per_device_train_batch_size=min(batch_size, max(len(train_pairs), 1)),
            logging_steps=10,
            save_strategy="no",
            report_to=[],
            disable_tqdm=True,
            use_cpu=not torch.cuda.is_available(),
        )

        trainer = Trainer(model=model, args=training_args, train_dataset=train_ds)
        train_result = trainer.train()

        final_dir = artifact_dir / "model"
        final_dir.mkdir(parents=True, exist_ok=True)
        model.save_pretrained(final_dir)
        tokenizer.save_pretrained(final_dir)

        model.eval()

        def _predict(text: str) -> str:
            enc = tokenizer(text, return_tensors="pt", truncation=True, max_length=64)
            enc.pop("token_type_ids", None)
            with torch.no_grad():
                logits = model(**enc).logits
                idx = int(torch.argmax(logits, dim=-1).item())
            return id2label.get(idx, UNKNOWN_INTENT)

        val_metrics = None
        if val_pairs:
            val_true = [l for _, l in val_pairs]
            t0 = time.perf_counter()
            val_pred = [_predict(t) for t, _ in val_pairs]
            val_latency_ms = (time.perf_counter() - t0) * 1000.0 / max(len(val_pairs), 1)
            val_metrics = _compute_metrics(val_true, val_pred, val_latency_ms)

        # Authoritative evaluation: the frozen test set. This is the ONLY
        # metric basis model_registry_service's regression gates should
        # trust, since it's the one slice guaranteed never to have been
        # trained on (dataset_service excludes any raw_config_hash match
        # against it at dataset-build time -- see Phase 7).
        frozen = load_frozen_test_set()
        if not frozen:
            raise RuntimeError(
                "Frozen evaluation set is empty or unavailable "
                f"(AI_FROZEN_TEST_SET_PATH={os.getenv('AI_FROZEN_TEST_SET_PATH', '<default>')}); "
                "refusing to certify a candidate without the authoritative eval artifact."
            )
        frozen_true = [ex.intent for ex in frozen]
        t1 = time.perf_counter()
        frozen_pred = [_predict(ex.text) for ex in frozen]
        frozen_latency_ms = (time.perf_counter() - t1) * 1000.0 / max(len(frozen), 1)
        frozen_metrics = _compute_metrics(frozen_true, frozen_pred, frozen_latency_ms)

        metrics: Dict[str, Any] = {
            # Top-level = frozen-test metrics, since that's what
            # model_registry_service.approve_candidate reads for
            # regression gates (macro_f1, unknown_f1) and what a
            # promotion decision should actually be based on.
            **{k: v for k, v in frozen_metrics.items() if k != "label_support"},
            "frozen_test": frozen_metrics,
            "validation": val_metrics,
            "training_loss": getattr(train_result, "training_loss", None),
            "epochs": epochs,
            "base_model": base_model,
            "train_examples": len(train_pairs),
            "val_examples": len(val_pairs),
            "frozen_test_examples": len(frozen),
            "dataset_version": dv.version,
            "dataset_hash": dv.dataset_hash,
        }

        artifact_hash = _hash_dir(final_dir)

        job.status = "COMPLETED"
        job.completed_at = datetime.utcnow()
        job.artifact_path = str(final_dir)
        job.artifact_hash = artifact_hash
        job.metrics = metrics
        db.commit()

        from app.services import model_registry_service
        system_user = type("SystemUser", (), {"username": job.created_by})()
        model_registry_service.create_candidate(
            db=db,
            model_name="distilbert-intent-classifier",
            model_type="classifier",
            dataset_version=dv.version,
            base_model_version=base_model,
            artifact_path=str(final_dir),
            model_hash=artifact_hash,
            metrics=metrics,
            training_job_id=job.id,
            user=system_user,
        )

    except Exception as e:
        job.status = "FAILED"
        job.error = str(e)
        job.completed_at = datetime.utcnow()
        db.commit()
