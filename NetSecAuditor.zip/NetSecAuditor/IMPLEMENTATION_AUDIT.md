# Implementation Audit

Scope note: this audit and the fixes below were produced from a single pass over
the repository as uploaded. The full 62-section brief (V4 dataset generation,
model retraining, full Keycloak/tenant test matrix, end-to-end demo, etc.) is a
multi-week program of work, not something that can be honestly completed in one
pass — so this document reports what was actually inspected and actually fixed,
not a claim that all 62 sections are done.

## What was inspected
- `backend/app/services/**` (deployment, config_injection, verification, ai,
  evidence/fabric/opa/batfish/minio/openbao wrappers) — all files `py_compile`d
  cleanly after fixes.
- `backend/app/routers/**`, `frontend/src/pages/**` — listed, checked for
  duplicate pages (none found).
- `.env.example` — checked against flags actually read via `os.environ` in code.

## Bugs found and fixed in this pass

1. **Corrupted filename `backend/app/services/registry.[y`** — a stray file
   with a broken extension sitting next to `registry.py`. Removed (dead
   weight, not imported anywhere).

2. **Dead duplicate service modules** at `backend/app/services/` top level:
   `gnmi.py`, `openconfig.py`, `pyats_genie.py`, `registry.py`, `result.py`,
   `ssh.py`. These were byte-for-byte or near-identical earlier drafts of the
   code that now correctly lives in the `services/config_injection/`,
   `services/verification/`, and `services/deployment/` sub-packages. Verified
   with a repo-wide grep that **nothing** imports the top-level versions
   (only `deployment_service.py`, `config_injection/registry.py`, and
   `verification/registry.py` are actually wired in, all pointing at the
   sub-packages). Deleted the six dead files. This directly matches the
   "duplicate implementations / dead code" risk called out in the brief —
   left in place, they're a real hazard: a future edit could touch the dead
   copy and silently do nothing.

3. **Missing `.env.example` entries** for the optional OpenConfig/gNMI and
   pyATS/Genie feature flags. The code already reads `GNMI_ENABLED`,
   `OPENCONFIG_ENABLED`, and `PYATS_ENABLED` via `os.environ.get(...)` with
   safe `false` defaults (confirmed in `config_injection/gnmi.py` and
   `verification/pyats_genie.py`), so behavior was already correct and
   optional-by-default — but the flags were undocumented, so an operator
   reading `.env.example` would not know they exist or how to turn them on.
   Added `OPENCONFIG_ENABLED`, `GNMI_ENABLED`, `GNMI_TIMEOUT`, `GNMI_PORT`,
   `GNMI_TLS_ENABLED`, `GNMI_CA_CERT`, `GNMI_CLIENT_CERT`, `GNMI_CLIENT_KEY`,
   `OPENCONFIG_MODEL_PATH`, `PYATS_ENABLED`, `PYATS_TESTBED_PATH`,
   `PYATS_TIMEOUT`, `PYATS_VERIFY_COMMANDS`, all defaulted off/safe, with
   comments reiterating the ChangeRequest-only workflow rule (section 24)
   and the "never authoritative" rule for pyATS.

4. Full `py_compile` pass over every `.py` file in `backend/` — no syntax
   errors found after the cleanup above (there were none before it either;
   the dead files were syntactically valid, just unused).

## Verified as already correctly implemented (spot-checked, not rewritten)
- `services/deployment/registry.py` — `get_deployer()` never silently
  substitutes a transport; `netconf` returns an explicit
  `NotImplementedError`-carrying result, `gnmi` returns explicit
  `GNMI_DISABLED`/`GNMI_UNAVAILABLE`/etc. statuses from `GnmiDeployer` rather
  than falling back — matches spec section 27.
- `config_injection/gnmi.py` — gated on `GNMI_ENABLED`, returns
  `GnmiResult(success=False, status=GNMI_DISABLED, ...)` rather than raising
  or faking success when disabled.
- `verification/pyats_genie.py` — gated on `PYATS_ENABLED`, and
  `deployment_service.py` only invokes it as supplemental post-deployment
  evidence, not as an authority over OPA/Batfish.
- No duplicate/near-duplicate frontend pages under `frontend/src/pages/`.

## Not inspected / not attempted in this pass (explicitly out of scope here)
- V4 dataset generation, leakage audit, DistilBERT retraining, MiniLM
  reference rebuild, hybrid calibration, error analysis (sections 6–17).
  These require the actual training data/model artifacts and a training run;
  none of that was present in the uploaded archive to operate on.
- Full Keycloak/tenant-isolation/credential-leak test matrix (sections
  18–20, 55) — would need a running Postgres/Keycloak/OpenBao stack to
  execute meaningfully rather than just read code.
- Mocked gNMI/pyATS test suites (sections 28, 34) — not present; adding a
  full suite is a substantial follow-on task, happy to do it as a next step
  if you want to scope it specifically.
- End-to-end demo run (section 56) — requires the docker-compose stack
  actually running.

## Follow-up pass: closed the two missing gNMI test scenarios

The mocked gNMI/pyATS suites (`test_config_injection_gnmi.py`,
`test_verification_pyats.py`, `test_change_request_gnmi_deploy_e2e.py`)
already covered nearly everything section 28/34 asks for. Two scenarios
called out explicitly in section 28 were genuinely missing, so they were
added to `test_change_request_gnmi_deploy_e2e.py` (same router-level,
no-real-network pattern as the existing e2e tests):

- `test_gnmi_deploy_aborts_on_stale_pre_change_hash` — proves
  `deployment_service.deploy_change_request` aborts with
  `status=ABORTED_STALE_HASH` *before* the gNMI injector's `capabilities()`
  or `set()` is ever called, when the device's live config no longer
  matches the hash the ChangeRequest was validated against (spec 25/43).
  The injector in this test raises `AssertionError` if called at all, so
  the test fails loudly if that ordering ever regresses.
- `test_gnmi_deploy_marks_drifted_on_post_verification_mismatch` — proves
  that if the gNMI `Set` reports success but the post-deployment collected
  config hash doesn't match the approved proposed hash, the
  `DeploymentRecord` is marked `DRIFTED` with `post_verification_passed=False`
  (spec 44), while the `ChangeRequest` itself is `DEPLOYED` (the push did
  happen — the drift is the reportable problem, not an undone deployment).

While writing the first test, found that `ChangeRequest.current_config_hash`
is only populated from the device's most recent prior `Scan` at CR-creation
time (`change_request_service.latest_known_config`), not re-collected live —
so a never-before-scanned device has `current_config_hash=None` and the
stale-hash check is a documented no-op. That's existing, intentional
behavior (not a bug), but it meant the test needed to monkeypatch a baseline
config in rather than relying on a bare new device. No production code was
changed for this — the intentional-no-op case just makes the test setup
slightly more deliberate.

Ran the full backend suite after these additions: **138 passed, 0 failed**
(`pytest tests/` from `backend/`), including all pre-existing tests — the
new tests are additive and nothing regressed.

## Follow-up pass 2: tenant-isolation test matrix (section 19)

`test_evidence_tenant_isolation.py`, `test_training_knowledge_tenant_isolation.py`,
and `test_change_requests.py` already covered evidence, training/knowledge-base
mappings, and change requests. Added `tests/test_cross_tenant_isolation_matrix.py`
closing the remaining gaps from the section-19 list, using the same
seed-a-second-tenant-directly-in-the-DB pattern as the existing tests:

- **Devices**: list excludes another tenant's device; get/collection-status/
  drift-by-device all 404 rather than leaking the other tenant's row.
- **Drift events**: list excludes another tenant's drift event.
- **Alerts**: list excludes another tenant's alert; acknowledging another
  tenant's alert 404s, and a DB check confirms it genuinely wasn't mutated.
- **Schedules**: list/get/patch/delete/run all 404 for another tenant's
  schedule; delete is confirmed to be a no-op via a DB check.
- **Compliance exceptions**: list excludes another tenant's exception;
  approve/reject both 404, and a DB check confirms the exception's status
  stayed `PENDING` (a cross-tenant approve/reject would otherwise silently
  override another tenant's OPA-derived finding — spec 45).

Result: **all 15 new tests passed on the first correctness pass** (one
early failure was in the test's own fixture data — `ComplianceException.
expires_at` is `nullable=False` and the first draft omitted it, an
IntegrityError caught immediately by running the test, not a bug in the
application). No application code needed to change: every router already
threaded `get_current_tenant()` through its queries correctly. This is a
genuinely good finding — it means the isolation *behavior* now has test
coverage locking it in place, rather than resting on a one-time manual
code read.

Full suite after this addition: **153 passed, 0 failed**
(`pytest tests/` from `backend/`).

## Follow-up pass 3: OpenBao secret-leak hardening (section 20)

Read every consumer of `openbao_service.get_device_credentials`/
`DeviceCredentials` (collectors, deployers, the pyATS verifier) and every
log/error/evidence/report path that could plausibly touch a secret. The
existing design was already good: `credential_ref` (not hostname/IP) is
the only thing that ever reaches PostgreSQL, `DeviceCredentials.secret` is
consistently scoped tightly to a single call, `VerificationResult.
as_metadata()` explicitly excludes credentials, and grepping for
log statements that mention credential/secret/password/token turned up
nothing suspicious.

The one real, if narrow, gap: several collectors/deployers/verifiers build
`error=f"...: {e}"` strings directly from third-party library exceptions
(netmiko, ncclient, pygnmi, pyats/unicon, httpx, pysnmp) while a
`credentials.secret` dict is in scope. Those libraries' exact exception
wording isn't under this codebase's control, and some versions of some
network-automation libraries are known to echo connection parameters —
including cleartext passwords — into exception messages. That `error`
string then flows into `CollectionResult`/`DeploymentResult`/
`VerificationResult`, which get persisted onto `Device.
last_collection_error`, `DeploymentRecord.error`, alerts, and reports.

Added `redact_secret_values(text, secret)` to `openbao_service.py` (the
one module already permitted to touch secret material) as a
defense-in-depth backstop: before any such exception-derived string is
returned, scrub every value from the in-scope `secret` dict that appears
verbatim in it (skipping values under 4 chars, e.g. port numbers, which
aren't meaningfully secret and would just mangle unrelated text). Wired
this into every exception-to-`error` site that has `secret`/`credentials`
in scope:

- `collectors/base.py` — the shared `timed()` catch-all wrapping every
  collector (SSH/NETCONF/RESTCONF/SNMP)
- `collectors/ssh.py`, `collectors/netconf.py`, `collectors/restconf.py`,
  `collectors/snmp.py` — their own specific except clauses
- `deployment/base.py` — the shared deployer `timed()` catch-all
- `deployment/ssh.py` — its specific except clauses
- `config_injection/gnmi.py` — both `capabilities()` and `set()` except
  blocks
- `verification/pyats_genie.py` — testbed-load and connect except blocks

Added `tests/test_credential_redaction.py`: unit tests for
`redact_secret_values` itself (redacts a leaked password, redacts
multiple distinct secret values, leaves clean text untouched, doesn't
mangle short values like port numbers, handles empty/None secrets, skips
non-string values), plus a regression test that mocks netmiko's
`ConnectHandler` to raise an exception whose message embeds the real
password, and confirms `SSHCollector.collect_config` never lets that
password reach `CollectionResult.error`.

Full suite after this addition: **160 passed, 0 failed**.

## Follow-up pass 4: general security sweep (section 54) + one real fix

Went looking specifically for security bugs rather than just checking off
audit-list items. Reviewed: JWT validation, CORS, SQL-injection surface,
MinIO object-key/path-traversal surface, docker-compose default secrets,
and role-gating consistency across mutating endpoints.

### Fixed: CORS wildcard + credentials (real vulnerability, not just a lint issue)

`app/main.py` previously hard-coded:
```python
allow_origins=["*"], allow_credentials=True
```
This is a genuine bug, not a style nit: per the CORS spec a wildcard
origin can never legitimately be paired with credentialed requests, and
Starlette's `CORSMiddleware` implements that pairing by echoing the
*actual* request `Origin` header back instead of a literal `"*"` whenever
`allow_credentials=True`. That means the old config granted **every
origin on the internet** permission to make credentialed cross-origin
requests against this API — the wildcard restricted nothing at all. (Real-
world exploitability was somewhat limited here because bearer tokens are
typically attached explicitly by frontend JS rather than sent
automatically like a cookie — but the server-side configuration itself
was wrong regardless of how today's frontend happens to consume it, and
it would matter immediately if any cookie-based session or a browser
extension/proxy attached the token automatically.)

Fixed by adding `CORS_ALLOWED_ORIGINS` (comma-separated env var):
- unset → no cross-origin browser access at all (same-origin/reverse-proxy
  only) — the new safe default, replacing the old wildcard default;
- an explicit list → only those origins, with credentials allowed;
- literal `*` → wildcard access granted, but credentials are force-disabled
  server-side so the invalid/unsafe combination can never occur.

Added `tests/test_cors_configuration.py` proving all three branches with
real `TestClient` requests (checking actual
`access-control-allow-origin`/`access-control-allow-credentials` response
headers, not just reading the code). Documented the new variable in
`.env.example`. Full suite after this fix: **163 passed, 0 failed**.

### Fixed: no production warning about docker-compose's demo secrets

`docker-compose.yml` ships hard-coded demo credentials for Postgres,
MinIO, Keycloak admin, OpenBao (`server -dev` with a fixed root token),
and Grafana — reasonable for a one-command local/demo stack, but the
README never said so. Added a explicit security note to the Quick Start
section calling out that these must change (and OpenBao specifically must
move off dev mode) before any non-localhost exposure.

### Findings documented but NOT unilaterally changed (policy decisions, not bugs)

- **Inconsistent role-gating on pipeline-triggering endpoints.**
  `routers/devices.py`'s live-collection endpoints (`/collect`, `/scan`)
  correctly require `require_role("admin", "operator")`, and
  `routers/change_request.py`'s mutating endpoints are similarly
  role-gated. But `routers/scans.py`'s `/upload`, `/bulk-upload`, and
  `/rerun` — which trigger the exact same compliance pipeline from an
  uploaded file instead of a live device — only require
  `get_current_user` (i.e., any authenticated role, including `viewer`).
  Given the role list explicitly includes a `viewer` role, it's a
  reasonable expectation that a viewer can't kick off new scans/pipeline
  runs — but I didn't want to unilaterally lock this down without
  confirming intent, since it's a genuine behavior change (a previously-
  working viewer workflow would start getting 403s) rather than a clear-
  cut security bug. **Recommendation**: decide the intended role for
  triggering a scan (likely `admin`/`security_analyst`/`operator`) and add
  the matching `require_role(...)` to those three endpoints for
  consistency with the device-collection path.
- Similarly, `POST /api/alerts/{id}/acknowledge` has no role restriction
  beyond authentication — worth deciding whether `viewer`/`auditor` should
  be able to acknowledge alerts or only operational roles.

### Reviewed and found clean

- No raw SQL anywhere in the backend (`grep` for `execute(`/string-built
  SQL against ORM patterns) — everything goes through SQLAlchemy's ORM,
  so no SQL-injection surface.
- MinIO object-key construction (`object_key(tenant_id, device_id,
  scan_id, filename)`) always uses server-generated UUIDs for
  tenant/device/scan components; every `filename` argument at every call
  site is a hard-coded literal (`"raw.cfg"`, `"proposed.cfg"`,
  `f"report.{fmt}"` with `fmt` validated against an explicit
  `("pdf", "json", "csv")` allow-list before use) — no path-traversal
  surface via user input.
- JWT validation (`auth/jwt.py`) already correctly pins `ALLOWED_ALGORITHMS
  = ["RS256"]` with an explicit comment about the classic
  algorithm-confusion attack (a token claiming `alg=HS256` being verified
  against the RSA public key as if it were an HMAC secret) — this is
  exactly right and I didn't find anything to improve here.
- No Dockerfiles contain hard-coded secrets.
- No `debug=True` / stack-trace-leaking exception handler in `main.py`.

## Recommendation for next step
Given the size of the remaining spec, the highest-value next slice is
probably either (a) the mocked gNMI/pyATS test suites in section 28/34,
since the adapters already exist and are wired correctly, or (b) actually
booting `docker-compose` here to smoke-test the stack end-to-end. Let me know
which you'd like to tackle next and I'll go deep on that one instead of
spreading thin across all 62 sections at once.
## Follow-up pass 5: Phase 5/6/7 -- real HITL Loop 2 training (largest remaining gap)

This was flagged explicitly as "currently the most important gap": the
existing `training_service.run_training_job` was a 67-line stub whose
only code path deliberately raised `RuntimeError("No GPU available or
training dependencies not fully configured")` on every call and reported
it as `FAILED` -- there was no training implementation to audit, just a
placeholder that always failed the same documented way.

### What was built

- **`app/ai/frozen_test_set.py`** + **`ai_frozen_test_v1.json`** (new): the
  authoritative, versioned evaluation artifact required by Phase 7 --
  56 hand-labeled examples across all 13 known intents plus explicit
  UNKNOWN cases, hashed with the same `sha256(text.encode())` scheme
  `pipeline.py` uses for `raw_config_hash`, so leakage detection actually
  catches a HITL example built from the same underlying raw config as a
  frozen-test item. This is a separate artifact from the HITL
  `training_examples` table by design (Phase 7 explicitly requires the
  frozen set never be built from the same table HITL corrections land
  in).

- **`app/services/dataset_service.py`** (rewritten): the old
  `_compute_hash` hashed only `id + raw_config_hash + human_action` (not
  real dataset content, so two datasets with different normalized facts
  could hash identically), and `frozen_test_hashes = set()` was
  hard-coded empty -- meaning Phase 7's leakage protection never ran, on
  any input. Fixed: `_compute_hash` now canonicalizes every
  training-relevant field (`raw_config_hash`, `raw_config_redacted`,
  `vendor`, `intent`, sorted `normalized_facts`, `human_action`, `source`)
  per example, sorted order-independently before hashing, so two builds
  of the same content always produce the same `dataset_hash`. Frozen-set
  leakage now actually loads from `frozen_test_set.py` and excludes any
  match. Also added real immutability: creating a `DatasetVersion` with
  an already-used version label is now a hard `ValueError`, not a silent
  re-populate.

- **`app/services/training_service.py`** (rewritten): real DistilBERT
  fine-tuning via `transformers.Trainer`, CPU-capable (`use_cpu=not
  torch.cuda.is_available()`), that:
  - Refuses to train on `< 6` examples, `< 2` classes, or any class with
    `< 2` examples -- explicit `RuntimeError` naming the actual
    under-represented classes, not a silently-degraded run.
  - Only trains on `APPROVED`/`CORRECTED` examples (never `REJECTED`).
  - Splits per-class into train/validation, fine-tunes, saves a real
    model artifact, and evaluates it twice: once against the held-out
    validation split, and once against the **frozen test set** -- the
    frozen-set metrics are what's stored at the top level of
    `TrainingJob.metrics` (and therefore what
    `model_registry_service.approve_candidate`'s regression gates read),
    since that's the only slice guaranteed never to have been trained on.
  - Computes accuracy/macro-precision/recall/F1/weighted-F1/unknown-P-R-F1
    directly (no new dependency) -- every number comes from actually
    running the fine-tuned model's predictions against real labels, none
    are fabricated.
  - Hashes the real artifact directory (`sha256` over every file's
    relative path + bytes) and records `artifact_path` +
    `TrainingJob.artifact_hash` (new column -- see migration below).
  - On any real failure (missing deps, bad data, training exception, or
    an empty/unavailable frozen test set), marks the job `FAILED` with
    the actual exception message -- there is no other terminal state.
  - On success, registers the result via the pre-existing
    `model_registry_service.create_candidate` as `CANDIDATE` -- never
    auto-promoted; human approval + explicit admin promotion are still
    required, exactly as before.

- **Migration `m8n9o0p1q2r3`** (new): adds `training_jobs.artifact_hash`.

### Bugs found only by actually executing the pipeline, not by reading code

Running `alembic upgrade head` against a throwaway SQLite DB (rather than
just reading the migration files) surfaced three real, pre-existing
defects that would break a clean install -- exactly what Phase 42 asks to
verify:

1. **Two divergent migration heads.** `L1m2n3o4p5q6` (training/HITL
   tables) branched off `h2i3j4k5l6m7`, while `k5l6m7n8o9p0` (device
   inventory fields) continued a separate branch through
   `i3j4k5l6m7n8` -> `j4k5l6m7n8o9`. `alembic upgrade head` cannot resolve
   two heads on its own. Fixed with an explicit merge migration
   (`m8n9o0p1q2r3`, which also carries the new `artifact_hash` column).

2. **A genuine duplicate revision ID.** Two unrelated migrations --
   `H2i3j4k5l6m7_extend_audit_log.py` and
   `h2i3j4k5l6m7_add_network_scan_jobs.py` -- both declared
   `revision = "h2i3j4k5l6m7"` (differing only by filename casing).
   Alembic warns ("Revision h2i3j4k5l6m7 is present more than once") but
   picks one arbitrarily, which is exactly the kind of ambiguity that
   works by accident until it doesn't. Re-threaded into a deterministic
   serial chain (audit-log extension now gets its own id, `h9i0j1k2l3m4`,
   ahead of network-scan-jobs in the chain) rather than leaving the
   collision in place.

3. **Duplicate index creation in two separate migrations.** Both
   `h2i3j4k5l6m7_add_network_scan_jobs.py` and
   `L1m2n3o4p5q6_add_training_hitl_tables.py` declared a `tenant_id`
   column with `index=True` on the `Column(...)` call *and* a separate
   explicit `op.create_index(...)` for the same column -- SQLAlchemy
   auto-creates the index from `index=True`, so the explicit call fails
   on a fresh install with `index ... already exists`. This wasn't a
   theoretical risk: `alembic upgrade head` genuinely could not complete
   on a clean database before this fix. Scanned the entire migration set
   programmatically for the same shape of bug afterward -- these were the
   only two instances.

After these three fixes, `alembic upgrade head` runs cleanly end-to-end
from a completely empty SQLite database with zero manual intervention
(verified; Postgres-specific DDL wasn't separately verified in this pass
-- see limitations below).

### Verified by actually running it, not just compiling it

`torch`/`transformers`/`accelerate` aren't reachable-by-default in this
sandbox (no network path to `huggingface.co`, and `accelerate` -- which
`transformers.Trainer` requires -- was **missing from
`requirements.txt` entirely**; added it, a real production dependency
gap this exercise caught). To prove the pipeline mechanically works
without a live download of the real `distilbert-base-uncased` weights,
built a throwaway tiny local DistilBERT checkpoint (random-init, small
hidden size, minimal vocab) as an offline test fixture, pointed
`AI_TRAINING_BASE_MODEL_PATH` at it, and ran the full path against real
`TrainingExample` rows in a fresh DB:

- Dataset build -> real canonicalized hash, correct example count.
- Training job -> `RUNNING` -> real `Trainer.train()` call, real non-zero
  training loss reported.
- Real artifact saved to disk, real SHA-256 hash computed from those
  files.
- Real evaluation against both the validation split and the actual
  56-example frozen set -- metrics reflect the (expectedly poor, since
  it's a random-init toy model trained 1 epoch on 6 examples) real
  predictions, not placeholders.
- Job -> `COMPLETED`, `ModelRegistryEntry` created with `status=CANDIDATE`.
- Confirmed the pre-existing regression gate in
  `model_registry_service.approve_candidate` genuinely rejects this weak
  candidate (`macro_f1 0.0095 < 0.85` floor) rather than rubber-stamping
  it -- `ValueError` raised, model auto-set to `REJECTED`.
- Separately confirmed the dependency-failure path is real too: before
  `accelerate` was added, the exact same run correctly ended in
  `FAILED` with the real `ImportError`/dependency message, not a
  fabricated success.

**UNVERIFIED -- dependency unavailable**: an actual fine-tuning run
against the real `distilbert-base-uncased` checkpoint (requires network
access to `huggingface.co`, unavailable in this sandbox) and against a
real GPU. The code path is identical either way (`AutoModel...
from_pretrained(base_model, ...)` where `base_model` defaults to the
public HF repo id); only the offline fixture stood in for the download
in this session.

### Full suite after this pass

`pytest tests/` from `backend/`: **241 passed, 5 failed, 1 skipped**
(baseline for comparison: 160 passed at end of pass 4, before ~30
additional pre-existing tests already in the repo were exercised in this
run alongside the new work -- no test regressed). All 5 failures were
individually root-caused and confirmed **pre-existing, unrelated to this
pass**:

- `test_normalization_pipeline.py::test_cisco_deterministic_facts_preserved`,
  `test_juniper_vendor_syntax_normalizes_to_common_concept`,
  `test_fortinet_nested_block_extracted` -- all three fail with
  `AttributeError: 'dict' object has no attribute 'id'/'name'` or
  `TypeError: argument of type 'NoneType' is not iterable` inside
  `app/models/baseline.py`'s pydantic model handling (VLANEntry/
  InterfaceEntry/ACLEntry deserializing as plain dicts instead of the
  expected model classes). Nothing in this pass touches
  `models/baseline.py`, `parsers.py`, or `normalize.py`.
- `test_fabric_service.py::test_anchor_evidence_idempotency_violation_raises`
  -- the test expects `FabricUnavailableError` to carry the string
  "idempotency violation" through from the mocked gateway's error body,
  but `fabric_service.py`'s retry-wrapping code replaces it with a
  generic "fabric-gateway unreachable after N attempts" message,
  swallowing the original error detail. Unrelated to this pass; not
  touched.
- `test_device_collection_endpoints.py::test_scan_endpoint_feeds_pipeline`
  -- fails on `respx.models.AllMockedAssertionError: RESPX: <Request
  POST http://opa.test/v1/data/compliance/evaluate> not mocked!`, i.e.
  the test's own mock setup doesn't cover a request the (unrelated,
  pre-existing) OPA call path makes. Unrelated to this pass; not touched.

Left all 5 as-is rather than fixing them in the same pass as the training
work, to keep this changeset auditable against a single, clearly-scoped
goal. Happy to take these on as the next slice if useful.

### Still not attempted (explicitly out of scope this pass)

- Wiring `training_jobs.py`'s `/run` endpoint to the existing
  NATS/worker background-job pattern (Phase 8 says training shouldn't
  run inline in a request). The endpoint still calls
  `training_service.run_training_job` synchronously, which is
  intentional for tests/demo but not what a real multi-user deployment
  should do for a fine-tuning run that can take minutes.
- Verifying the merged migration chain against real Postgres (only
  SQLite was exercised in this sandbox).
- Sections 8-52 of the original brief not covered by passes 1-5 above
  (multi-vendor parser coverage expansion, Fabric hardware E2E, frontend
  page-by-page audit, full observability/OTel spans, etc.) -- still a
  multi-week program, not attempted here.
