"""
Frozen evaluation set (Phase 7).

The authoritative frozen test set for classifier training/evaluation is a
checked-in, versioned JSON artifact -- NOT derived from HITL
TrainingExample rows. This is deliberate: if the frozen set were built
from the same table that HITL corrections land in, a human reviewer could
(even accidentally) approve an example whose raw_config_hash collides with
a "held out" example, silently contaminating the set that's supposed to
measure generalization.

AI_FROZEN_TEST_SET_PATH selects which versioned artifact is authoritative.
Defaults to the v1 artifact shipped in this repo. Bumping to a new frozen
set requires a new file (ai_frozen_test_v2.json, ...) and an explicit env
change -- never an in-place edit of an existing version.
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from typing import List, Optional, Set

_DEFAULT_RELATIVE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "ai_frozen_test_v1.json",
)


@dataclass
class FrozenExample:
    text: str
    intent: str
    vendor: Optional[str]
    raw_config_hash: str


def _hash_text(text: str) -> str:
    # Must match pipeline.py's raw_config_hash computation exactly
    # (hashlib.sha256(raw_text.encode()).hexdigest()) so that leakage
    # detection actually catches a HITL example built from the same
    # underlying raw config as a frozen-test item.
    return hashlib.sha256(text.encode()).hexdigest()


def frozen_test_set_path() -> str:
    return os.getenv("AI_FROZEN_TEST_SET_PATH", _DEFAULT_RELATIVE_PATH)


_cache: Optional[List[FrozenExample]] = None
_cache_path: Optional[str] = None


def load_frozen_test_set(force_reload: bool = False) -> List[FrozenExample]:
    global _cache, _cache_path
    path = frozen_test_set_path()
    if not force_reload and _cache is not None and _cache_path == path:
        return _cache

    if not path or not os.path.isfile(path):
        # Explicit empty set, not a silently-fabricated one. Callers must
        # treat an empty frozen set as "evaluation artifact unavailable",
        # not as "0 examples means 100% pass".
        _cache, _cache_path = [], path
        return _cache

    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    examples = [
        FrozenExample(
            text=item["text"],
            intent=item.get("intent", "UNKNOWN"),
            vendor=item.get("vendor"),
            raw_config_hash=_hash_text(item["text"]),
        )
        for item in raw
    ]
    _cache, _cache_path = examples, path
    return examples


def frozen_test_hashes() -> Set[str]:
    """raw_config_hash values that must never appear in a training split."""
    return {ex.raw_config_hash for ex in load_frozen_test_set()}
